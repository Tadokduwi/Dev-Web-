import Link from 'next/link'
import React from 'react'

export default function index() {
  return (

<html>
<head>
  <title>Dev Web</title>
  <link rel="stylesheet" href="globals.css"></link>
</head>
<body>
  
  <header>
    <div class="nav">
      <ul>
        <li class ="devweb">DevWeB</li>
        <li class="home"><a href="#">Home</a></li>
        <li class="tutorials"><a href ="#">RepairSystem </a>
          <ul>
            <li><a href="#">Request_Repair</a></li>
            <li><a href="#">RepairAssignment</a></li>
            <li><a href="#">Approval</a></li>
            <li><a href="#">MyRepairJob</a></li>
            <li><a href="#">RepairTracking</a></li>
          </ul>
        </li>
        <li class="tutorials"><a href ="#">PM/AMCheckSystem </a>
          <ul>
            <li><a href="#">Assignment</a></li>
            <li><a href="#">MyPM/AM</a></li>
          </ul>
        </li>
        <li class="tutorials"><a href ="#">SparePartSystem </a>
          <ul>
            <li><a href="#">SparePartStock</a></li>
            <li><a href="#">GoodReceiving</a></li>
            <li><a href="#">AdjustInventory</a></li>
          </ul>
        </li>
        <li class="tutorials"><a href ="#">PropertyRegistration</a>
          <ul>
            <li><a href="#">Machine/ToolList</a></li>
            <li><a href="#">AddMachineToolList</a></li>
          </ul>
        </li>
        {/* <li class="about"><a class ="active" href ="#">About</a></li> */}
        <li class="news"><a href ="#">Others</a>
          <ul>
            <li><a href="#">Add-onServices</a></li>
            <li><a href="#">LiveChatwithTechnicians</a></li>
            <li><a href="#">ContactTechnical</a></li>
            <li><a href="#">ReviewApp</a></li>
            <li><a href="#">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </header>
</body>
</html>

  )
}

